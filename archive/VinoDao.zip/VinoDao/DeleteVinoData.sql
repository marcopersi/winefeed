delete from wineoffering;
delete from offering;
delete from wine;
delete from unit;
delete from rating;
delete from ratingagency;
delete from provider;
