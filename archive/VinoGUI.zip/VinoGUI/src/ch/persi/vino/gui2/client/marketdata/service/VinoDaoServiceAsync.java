package ch.persi.vino.gui2.client.marketdata.service;

import ch.persi.vino.gui2.client.lib.GenericGwtRpcServiceAsync;
import ch.persi.vino.gui2.shared.WineOffering;

public interface VinoDaoServiceAsync extends
		GenericGwtRpcServiceAsync<WineOffering> {

}
