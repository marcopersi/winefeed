package ch.persi.vino.gui2.server;

import com.google.gwt.user.server.rpc.RemoteServiceServlet;

public class VinoLotServiceImpl extends RemoteServiceServlet {

}
